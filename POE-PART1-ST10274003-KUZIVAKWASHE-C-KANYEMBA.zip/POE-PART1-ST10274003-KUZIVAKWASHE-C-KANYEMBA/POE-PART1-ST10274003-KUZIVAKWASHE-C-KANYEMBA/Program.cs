﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_PART1_ST10274003_KUZIVAKWASHE_C_KANYEMBA
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize varibles
            int ingredientCount;
            int stepCount;
            Recipe recipe;

            // Prompt for entering ingredients.
            Console.Write("Enter number of ingredients: ");
            while (!int.TryParse(Console.ReadLine(), out ingredientCount) || ingredientCount <= 0)
            {
                Console.Write("Please enter a valid number: ");
                Console.WriteLine();
            }

            // Prompt to enter number of steps for recipe.
            Console.Write("Enter number of steps for recipe: ");
            while (!int.TryParse(Console.ReadLine(), out stepCount) || stepCount <= 0)
            {
                Console.Write("Please enter valid number of steps: ");
                Console.WriteLine();
            }

            // Creating a new recipe object.
            recipe = new Recipe(ingredientCount, stepCount);

            Console.WriteLine();
            // Prompt user to enter ingredients
            for(int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity;
                while(!double.TryParse(Console.ReadLine(), out quantity) || quantity <=0 )
                {
                    Console.Write("Please enter a valid number for quantity: ");
                }
                Console.Write("Unit: ");
                string unit = Console.ReadLine();

                Console.WriteLine();
                // Ingredient object to add to recipe.
                recipe.AddIngredient(i, new Ingredient(name, quantity, unit));
                
            }

            // User prompt to enter steps
            for(int i = 0; i < stepCount; i++)
            {
                Console.Write($"Enter step {i + 1}:");
                string step = Console.ReadLine();
                recipe.AddStep(i, step);
            }

            Console.WriteLine();
            recipe.DisplayRecipe();
            Console.WriteLine();

            // Prompts to scale, reset and clear recipe.
            Console.WriteLine("Select the below Options");
            Console.WriteLine("1. Scale the recipe.");
            Console.WriteLine("2. Reset the recipe.");
            Console.WriteLine("3. Clear the recipe.");

            int choice;
            while(!int.TryParse(Console.ReadLine(), out choice) || (choice != 1 && choice !=2 && choice !=3))
            {
                Console.WriteLine("Please enter a valid choice number: ");
            }
            Console.WriteLine();

            if(choice==1)
            {
                Console.WriteLine("Enter scaling factor: ");
                double factor;
                while(!double.TryParse(Console.ReadLine(), out factor) || factor <= 0)
                {
                    Console.WriteLine("Enter a valid number: ");
                }
                Console.WriteLine();
                recipe.Scale(factor);
            }
            else if(choice==2)
            {
                recipe.Reset();
                Console.WriteLine("Recipe has been reset to original.");
            }
            else if(choice==3)
            {
                recipe.Clear();
                Console.WriteLine("Recipe has been cleared.");
            }
            Console.ReadLine();
        }

        // A class to represent the ingredients.
        public class Ingredient
        {
            // Declaration of variables.
            public string Name;
            public double Quantity;
            public string Unit;

            // Constructor to initialize Ingredient
            public Ingredient(string name, double quantity, string unit)
            {
                Name = name;
                Quantity = quantity;
                Unit = unit;
            }
        }

        // The Recipe class
        public class Recipe
        {
            // array to store Ingredients for the Recipe
            private Ingredient[] ingredients;
            private string[] steps; // Array to store number of steps entered.

            // Constructor to initialize Recipe object with given ingredient
            public Recipe(int ingredientCount, int stepCount)
            {
                ingredients = new Ingredient[ingredientCount];
                steps = new string[stepCount];
            }

            // Method to add ingredient to the recipe.
            public void AddIngredient(int index, Ingredient ingredient)
            {
                if (index >= 0 && index < ingredients.Length)
                {
                    ingredients[index] = ingredient;
                }
                else
                {
                    Console.WriteLine("Invalid index for adding ingredient.");
                }
            }

            // Method to add a step to recipe.
            public void AddStep(int index, string step)
            {
                if (index >= 0 && index < steps.Length)
                {
                    steps[index] = step;
                }
                else
                {
                    Console.WriteLine("Invalid input for step: ");
                }
            }

            // Method to display the recipe
            public void DisplayRecipe()
            {
                Console.WriteLine("*************************");
                Console.WriteLine("Recipe ");
                Console.WriteLine("*************************");
                Console.WriteLine("Ingredients: ");
                foreach(var ingredient in ingredients)
                {
                    Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
                }
                Console.Write("Steps: ");
                for(int i = 0; i < steps.Length; i++)
                {
                    Console.Write($"{i + 1}. { steps[i]}");
                }
            }

            // Method to scale the recipe
            public void Scale(double factor)
            {
                foreach(var ingredient in ingredients)
                {
                    ingredient.Quantity *= factor;
                }
            }

            // Method to reset Ingredient 
            public void Reset()
            {
                foreach(var ingredient in ingredients)
                {
                    Console.WriteLine($"Resetting quantity of {ingredient.Name} to original value");
                }
            }

            // Method to clear data
            public void Clear()
            {
                ingredients = new Ingredient[ingredients.Length];
                steps = new string[steps.Length];
            }
        }
    }
}
